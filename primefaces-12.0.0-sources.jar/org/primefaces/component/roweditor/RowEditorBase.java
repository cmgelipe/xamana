/*
 * The MIT License
 *
 * Copyright (c) 2009-2022 PrimeTek
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
package org.primefaces.component.roweditor;

import javax.faces.component.UIComponentBase;


public abstract class RowEditorBase extends UIComponentBase {

    public static final String COMPONENT_FAMILY = "org.primefaces.component";

    public static final String DEFAULT_RENDERER = "org.primefaces.component.RowEditorRenderer";

    public enum PropertyKeys {

        style,
        styleClass,
        editTitle,
        cancelTitle,
        saveTitle;
    }

    public RowEditorBase() {
        setRendererType(DEFAULT_RENDERER);
    }

    @Override
    public String getFamily() {
        return COMPONENT_FAMILY;
    }

    public String getStyle() {
        return (String) getStateHelper().eval(PropertyKeys.style, null);
    }

    public void setStyle(String style) {
        getStateHelper().put(PropertyKeys.style, style);
    }

    public String getStyleClass() {
        return (String) getStateHelper().eval(PropertyKeys.styleClass, null);
    }

    public void setStyleClass(String styleClass) {
        getStateHelper().put(PropertyKeys.styleClass, styleClass);
    }

    public String getEditTitle() {
        return (String) getStateHelper().eval(PropertyKeys.editTitle, null);
    }

    public void setEditTitle(String editTitle) {
        getStateHelper().put(PropertyKeys.editTitle, editTitle);
    }

    public String getCancelTitle() {
        return (String) getStateHelper().eval(PropertyKeys.cancelTitle, null);
    }

    public void setCancelTitle(String cancelTitle) {
        getStateHelper().put(PropertyKeys.cancelTitle, cancelTitle);
    }

    public String getSaveTitle() {
        return (String) getStateHelper().eval(PropertyKeys.saveTitle, null);
    }

    public void setSaveTitle(String saveTitle) {
        getStateHelper().put(PropertyKeys.saveTitle, saveTitle);
    }

}